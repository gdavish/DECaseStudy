package modules;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CustDAOImpl implements CustomerDAO {
	private static final String Customer = null;
	static Connection myConn = null;
		static Statement myStmt = null;
		static ResultSet myRs = null;
		static PreparedStatement query = null;
		
		String dbUrl = "jdbc:mysql://localhost:3306/cdw_sapp"; //database url
		String user = "root";
		String pass = "mysql";
 @Override
	public Customer retrieveCustomer(String Customer) throws SQLException{
	Customer c=new Customer();	
		try {
			// 1. Get a connection to database
			myConn = DriverManager.getConnection(dbUrl, user , pass);
			
			System.out.println("Database connection successful!\n");    //123458614
			
			// 2. Create a statement
			myStmt = myConn.createStatement(); //allows to create statement 
			
			// 3. Execute SQL query
			query = myConn.prepareStatement("select* from cdw_sapp_customer where ssn=?" );  //use sql statement to retrieve all columns table "
			query.setString(1, Customer);
			ResultSet result = query.executeQuery();
			
			// 4. Process the result set
			if(result.next()) { 
				c.setCard_no(result.getString("credit_card_no"));
				c.setFirst_Name(result.getString("First_Name"));
				c.setMiddle_Name(result.getString("Middle_Name"));
				c.setLast_Name(result.getString("Last_Name"));
				c.setSsn(result.getLong("ssn"));
				c.setStreet_Name(result.getString("Street_Name"));
				c.setAPT_No(result.getLong("APT_No"));
				c.setCust_City(result.getString("Cust_City"));
				c.setCust_State(result.getString("Cust_State"));
				c.setCust_Country(result.getString("Cust_Country"));
				c.setCust_Zip(result.getLong("Cust_Zip"));
				c.setCust_Phone(result.getLong("Cust_Phone"));
				c.setCust_Email(result.getString("Cust_Email"));
				c.setLast_Updated(result.getString("Last_Updated"));
			}
			myConn.close();
		}
		catch (Exception e) {System.out.println(e);}
			return c;
		}
public static int update(Customer c){
		int status=0;
		try{
			myConn = DriverManager.getConnection(dbUrl, user , pass);
			
			System.out.println("Database connection successful!\n");
			
			myStmt = myConn.createStatement(); //allows to create statement 
			
			query = myConn.prepareStatement("update cdw_sapp_customer set card_no=?,First_Name=?,Middle_Name=?,Last_Name=?,Street_Name=?,APT=?,City=?,State=?,Country=?,Zip=?,Phone=?,Email=?,Last_Updated=? where ssn=?");
			query.setString(1,c.getCard_No());
			query.setString(2,c.getFirst_Name());
			query.setString(3, c.getMiddle_Name());
			query.setString(4,c.getLast_Name());
			query.setLong(5,c.getSsn());
			query.setString(6,c.getStreet_Name());
			query.setLong(7,c.getAPT_No());
			query.setString(8,c.getCust_City());
			query.setString(9,c.getCust_State());
			query.setString(10,c.getCust_Country());
			query.setLong(11,c.getCust_Zip());
			query.setFloat(12,c.getCust_Phone());
			query.setString(13,c.getCust_Email());
			query.setString(14,c.getLast_Updated());
			status=query.executeUpdate();
			myConn.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public Transactions generateBill(String Transactions) throws SQLException{
	Transactions t=new Transactions();	
		try {
			// 1. Get a connection to database
			myConn = DriverManager.getConnection(dbUrl, user , pass);
			
			System.out.println("Database connection successful!\n");    //123458614
			
			// 2. Create a statement
			myStmt = myConn.createStatement(); //allows to create statement 
			
			// 3. Execute SQL query
			query = myConn.prepareStatement("select sum(Transaction_Value) from cdw_sapp_creditcard where card_no=? AND month=? AND year=?" );  //use sql statement to retrieve all columns table "
			query.setString(1, Transactions);
			ResultSet result = query.executeQuery();
			
			// 4. Process the result set
			if(result.next()) { 
				t.setCardNo(result.getString("card_no"));
				t.setValue(result.getDouble("transaction_value"));
				t.setMonth(result.getInt("Month"));
				t.setYear(result.getInt("Year"));
			}
			myConn.close();
		}
		catch (Exception e) {System.out.println(e);}
			return t;
		}
		public Transactions displayTrans(String Transactions) throws SQLException{
	Transactions t=new Transactions();	
	Customer c=new Customer();
		try {
			// 1. Get a connection to database
			myConn = DriverManager.getConnection(dbUrl, user , pass);
			
			System.out.println("Database connection successful!\n");    //123458614
			
			// 2. Create a statement
			myStmt = myConn.createStatement(); //allows to create statement 
			
			// 3. Execute SQL query
			query = myConn.prepareStatement("select Transaction_Type,Transaction_Value,First_Name,Middle_Name,Last_Name from cdw_sapp_creditcard, cdw_sapp_customer where ssn=? AND (month between '?' AND '?') AND (day between '?' AND '?') AND (year BETWEEN '?' AND '?'" );  //use sql statement to retrieve all columns table "
			query.setString(1, Transactions);
			query.setString(2, Customer);
			ResultSet result = query.executeQuery();
			
			// 4. Process the result set
			if(result.next()) { 
				t.setValue(result.getLong("transaction_value"));
				t.setType(result.getString("transaction_type"));
				c.setFirst_Name(result.getString("First_Name"));
				c.setMiddle_Name(result.getString("Middle_Name"));
				c.setLast_Name(result.getString("Last_Name"));
				c.setSsn(result.getLong("ssn"));
				t.setMonth(result.getInt("Month"));
				t.setDay(result.getInt("Day"));
				t.setYear(result.getInt("Year"));
			}
			myConn.close();
		}
		catch (Exception e) {System.out.println(e);}
			return t;
		}
		@Override
		public void updateCustomer(Customer c) throws SQLException {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void displayTrans(String Transactions, String Customer) throws SQLException {
			// TODO Auto-generated method stub
			
		}
			}
		
		
	

