package modules;

import java.sql.SQLException;

public interface CustomerDAO {

	public Customer retrieveCustomer(String Customer) throws SQLException;
	public void updateCustomer(Customer c) throws SQLException;
	public Transactions generateBill(String Transactions) throws SQLException;
	public void displayTrans(String Transactions, String Customer) throws SQLException;
	    

}
