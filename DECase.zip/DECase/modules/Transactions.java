package modules;

public class Transactions {
	String card_no;
	int day;
	int month;
	int year;
	long cust_ssn;
	long branch_code;
	String transaction_type;
	double transaction_value;
public Transactions(String card_no, int day, int month, int year, long ssn, 
		             long code, String type, double value) {
	this.card_no = card_no;
	this.day = day;
	this.month = month;
	this.year = year;
	this.cust_ssn = ssn;
	this.branch_code = code;
	this.transaction_type = type;
	this.transaction_value = value;
	// TODO Auto-generated constructor stub
}

public Transactions() {
	// TODO Auto-generated constructor stub
}

public String getCardNo() {
	return card_no;
}

public void setCardNo(String card_no) {
	this.card_no = card_no;
}

public int getDay() {
	return day;
}

public void setDay(int day) {
	this.day = day;
}

public int getMonth() {
	return month;
}

public void setMonth(int month) {
	this.month = month;
}

public int getYear() {
	return year;
}

public void setYear(int year) {
	this.year = year;
}
public long getSSN() {
	return cust_ssn;
}

public void setSSN(long ssn) {
	this.cust_ssn = ssn;
	
}
public long getCode() {
	return branch_code;
}

public void setCode(long code) {
	this.branch_code = code;
}
public String getType() {
	return transaction_type;
}

public void setType(String type) {
	this.transaction_type = type;
}
public double getValue() {
	return transaction_value;
}

public void setValue(double value) {
	this.transaction_value = value;
}
}
