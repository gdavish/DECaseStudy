package modules;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		try{
			Scanner input = new Scanner(System.in);
			System.out.print("Enter 1 to View customer, 2 to update");
			int choose = input.nextInt();
			
			switch(choose){
			
			/* Retrieve */
			case 1 :
				System.out.print("enter SSN:");
				String Customer = input.next();
				CustDAOImpl test1 = new CustDAOImpl ();
				test1.retrieveCustomer(Customer);
		
				break;
				
				/* update */	

			case 2:

				System.out.print("enter ssn: ");

				String ssn1 = input.nextLine();

				

				System.out.print("enter First Name: ");

				String First_Name1 = input.nextLine();

				

				System.out.print("enter Middle Name: ");

				String Middle_Name1 = input.nextLine();

				

				System.out.print("enter product production date: ");

				String Last_Name1 = input.nextLine();

		

				System.out.print("enter Street Name: ");

				String Street_Name1 = input.nextLine();

			

				

				

				Customer c2 = new Customer();

				c2.setFirst_Name(First_Name1);

				c2.setLast_Name(Last_Name1);

				c2.setStreet_Name(Street_Name1);

				

				CustDAOImpl tst2 = new CustDAOImpl();

				tst2.updateCustomer(c2);		

			

			break;
			
			}
			
			
			}
			
			catch (Exception e){
				System.out.print("plesae enter a valid number");
			}
				
		// TODO Auto-generated method stub

	}

}
