package modules;

public interface TransactionsDao {
	
	  public void retrieveZip(Transactions transaction);
	  public void retrieveTotalType(Transactions transaction);
	  public void retrieveTotalBranch(Transactions transaction);
		

}
