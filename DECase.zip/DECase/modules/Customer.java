package modules;

public class Customer {
	String Credit_Card_no;
	String First_Name;
	String Middle_Name;
	String Last_Name;
	long ssn;
	String Street_Name;
	long APT_No;
	String Cust_City;
	String Cust_State;
	String Cust_Country;
	long Cust_Zip;
	long Cust_Phone;
	String Cust_Email;
	String Last_Updated;
	
public Customer(String card_no, String First_Name, String Middle_Name, String Last_Name, long ssn, 
				String Street_Name, long APT, String City, String State, String Country, 
				long Zip, long Phone, String Email, String Updated) {
	this.Credit_Card_no = card_no;
    this.First_Name = First_Name;
	this.Middle_Name = Middle_Name;
	this.Last_Name = Last_Name;
	this.ssn = ssn;
	this.Street_Name = Street_Name ;
	this.APT_No = APT;
	this.Cust_City = City;
	this.Cust_State = State;
	this.Cust_Country = Country;
	this.Cust_Zip = Zip;
	this.Cust_Phone = Phone;
	this.Cust_Email = Email;
	this.Last_Updated = Last_Updated;
	// TODO Auto-generated constructor stub
}

public Customer() {
	// TODO Auto-generated constructor stub
}

public String getCard_No() {
	return Credit_Card_no;
}

public void setCard_no(String card_no) {
	this.Credit_Card_no = card_no;
}

public String getFirst_Name() {
	return First_Name;
}

public void setFirst_Name(String First_Name) {
	First_Name = First_Name;
}

public String getMiddle_Name() {
	return Middle_Name;
}

public void setMiddle_Name(String middle_Name) {
	Middle_Name = middle_Name;
}

public String getLast_Name() {
	return Last_Name;
}

public void setLast_Name(String last_Name) {
	Last_Name = last_Name;
}

public long getSsn() {
	return ssn;
}

public void setSsn(long ssn) {
	this.ssn = ssn;
}

public String getStreet_Name() {
	return Street_Name;
}

public void setStreet_Name(String street_Name) {
	Street_Name = street_Name;
}

public long getAPT_No() {
	return APT_No;
}

public void setAPT_No(long APT) {
	APT_No = APT;
}

public String getCust_City() {
	return Cust_City;
}

public void setCust_City(String City) {
	Cust_City = City;
}

public String getCust_State() {
	return Cust_State;
}

public void setCust_State(String State) {
	Cust_State = State;
}

public String getCust_Country() {
	return Cust_Country;
}

public void setCust_Country(String Country) {
	Cust_Country = Country;
}

public long getCust_Zip() {
	return Cust_Zip;
}

public void setCust_Zip(long Zip) {
	Cust_Zip = Zip;
}

public long getCust_Phone() {
	return Cust_Phone;
}

public void setCust_Phone(long Phone) {
	Cust_Phone = Phone;
}

public String getCust_Email() {
	return Cust_Email;
}

public void setCust_Email(String Email) {
	Cust_Email = Email;
}

public String getLast_Updated() {
	return Last_Updated;
}

public void setLast_Updated(String Last_Updated) {
	Last_Updated = Last_Updated;
}
}